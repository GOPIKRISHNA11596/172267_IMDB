export class AdditinalServicePojo {
    typeOfVechile:string 
	partOfDay:string 
	dirtyVechile:string 
    email:string
}
