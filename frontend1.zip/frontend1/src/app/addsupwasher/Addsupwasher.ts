export class Addsupwasher{
    supervisorname:string
    washermanname:string
}