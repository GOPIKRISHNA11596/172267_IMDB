export class DailytasksPojo 
{
    location:string
    date:string
}