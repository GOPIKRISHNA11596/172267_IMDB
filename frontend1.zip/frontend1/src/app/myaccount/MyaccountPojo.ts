export class MyaccountPojo{
    email:string;
    location:string;
    date:string;

    vehiclenumber:string;

	typeOfVechile:string;
    partOfDay:string;
    
    nameoncard:string;
    creditcardnumber:string;
    
    membershipName:string;
	freewash:string;
	polishing:string;
}