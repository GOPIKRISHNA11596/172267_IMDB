export class MemberShipPojo
{
    email:string
    membership:string
    // freewash:string
	//  polishing:string

}