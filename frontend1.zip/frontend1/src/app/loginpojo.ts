export class LoginPojo {
    email:string
password:string
   
}
